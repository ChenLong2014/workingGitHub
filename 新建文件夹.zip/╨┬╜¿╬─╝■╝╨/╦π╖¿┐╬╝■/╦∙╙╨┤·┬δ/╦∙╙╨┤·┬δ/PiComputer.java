/**
 * Piֵ������
 *
 * @author luwei
 * @version 1.0 2017-12-19
 */

import java.util.*;

public final class PiComputer{

	//���Ͷ�㷨����Piֵ
	public static double darts(int n){
		Random random1 = new Random();
		Random random2 = new Random();

		int k = 0;
		for(int i=1; i<=n; i++){
			
			double x = random1.nextDouble();
			double y = random2.nextDouble();

			if(x*x + y*y <= 1.0 ){
				k++;
			}
		}
		return 4*k/(double)n;
	}

	public static double avgDarts(int n){
		
		int num = 100;
		double pi = 0;

		for(int i=1; i<=num; i++){
			pi += darts(n);
		}
		return (double)pi/num;
	}

	public static void main(String[] args){

		System.out.println("Pi�� " + darts(1000000));
		System.out.println("Pi�� " + avgDarts(1000000));
	}
}