/**
 * 随机数测试
 *
 */
import java.util.Random;

public final class RandomTest{

	public static void main(String[] args){

		int n = 2;
		int m = 100;
		Random rand = new Random();
//		int[] ranSeq = new int[n];
		int[][] statis = new int[2][n];

		for(int i=0; i<n; i++) statis[0][i] = i;

		for(int j=0; j<m; j++) {
			for(int i=0; i<n; i++) {
				statis[1][rand.nextInt(n)]++;
			}
		}		

		System.out.printf("%3d", statis[0][0]);
		for(int i=1; i<n; i++) {
			System.out.printf("%s%3d", ", ", statis[0][i]);
		}
		System.out.println();
		System.out.printf("%3d", statis[1][0]);
		for(int i=1; i<n; i++) {
			System.out.printf("%s%3d", ", ", statis[1][i]);
		}
	}
}
